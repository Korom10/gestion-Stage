from django.shortcuts import render, redirect 
from .models import Stagiaire, Departement, Encadreur, Theme, Suivi
from .forms import StagiaireForm, DepartementForm, EncadreurForm, ThemeForm, SuiviForm
from django.http import  HttpResponseRedirect


def add_stagiaire(request):
    submitted = False
    if request.method == "POST":
        form = StagiaireForm(request.POST)
        if form.is_valid():
            form.save()
            return HttpResponseRedirect('/add_stagiaire?submitted=True')
    else:
        form = StagiaireForm
        if 'submitted' in request.GET:
            submitted=True
    return render(request, 'dashbord/add_stagiaire.html', {
        'form': form,
        'submitted': submitted,
    })
def stagiaire(request):
     stagiaires = Stagiaire.objects.all()
     return render(request, 'dashbord/stagiaire.html', {
        'stagiaires': stagiaires 
    })

def add_departement(request):
    submitted = False
    if request.method == "POST":
        form = DepartementForm(request.POST)
        if form.is_valid():
            form.save()
            return HttpResponseRedirect('/add_departement?submitted=True')
    else:
        form = DepartementForm
        if 'submitted' in request.GET:
            submitted=True
    return render(request, 'dashbord/add_departement.html', {
        'form': form,
        'submitted': submitted,
    })
    
def add_encadreur(request):
    submitted = False
    if request.method == "POST":
        form = EncadreurForm(request.POST)
        if form.is_valid():
            form.save()
            return HttpResponseRedirect('/add_encadreur?submitted=True')
    else:
        form = EncadreurForm
        if 'submitted' in request.GET:
            submitted=True
    return render(request, 'dashbord/add_encadreur.html', {
        'form': form,
        'submitted': submitted,
    })
    
def add_theme(request):
    submitted = False
    if request.method == "POST":
        form = ThemeForm(request.POST)
        if form.is_valid():
            form.save()
            return HttpResponseRedirect('/add_theme?submitted=True')
    else:
        form = ThemeForm
        if 'submitted' in request.GET:
            submitted=True
    return render(request, 'dashbord/add_theme.html', {
        'form': form,
        'submitted': submitted,
    })
def add_suivi(request):
    submitted = False
    if request.method == "POST":
        form = SuiviForm(request.POST)
        if form.is_valid():
            form.save()
            return HttpResponseRedirect('/add_suivi?submitted=True')
    else:
        form = SuiviForm
        if 'submitted' in request.GET:
            submitted=True
    return render(request, 'dashbord/add_suivi.html', {
        'form': form,
        'submitted': submitted,
    })

    
     
def index(request):
    suivi = Suivi.objects.all()
    all_departements = Departement.objects.all().count()
    all_stagiaires = Stagiaire.objects.all().count()
    all_encadreurs = Encadreur.objects.all().count()
    all_themes = Theme.objects.all().count()

    context = {
     'suivi': suivi,
     'all_departements' : all_departements,
     'all_stagiaires' : all_stagiaires,
     'all_encadreurs' : all_encadreurs,
     'all_themes' : all_themes,
    }
    return render(request, 'dashbord/index.html', context)


def suivi(request):
    suivi = Suivi.objects.all()
    context = {
     'suivis': suivi
    }
    return render(request, 'dashbord/suivi.html', context)

# def stagiaire(request):
#     stagiaires = Stagiaire.objects.all()
#     context = {
#      'stagiaires': stagiaires
#     }
#     return render(request, 'dashbord/stagiaire.html', context)

# def suivi(request):
#     suivi = Suivi.objects.all()
#     context = {
#      'suivi': suivi
#     }
#     return render(request, 'dashbord/suivi.html', context)
def departement(request):
    departements = Departement.objects.all()
    context = {
     'departements': departements
    }
    return render(request, 'dashbord/departement.html', context)

# def suivi(request):
#     suivis = Suivi.objects.all()
#     context = {
#      'suivis': suivis
#     }
#     return render(request, 'dashbord/suivi.html', context)

def theme(request):
    themes = Theme.objects.all()
    context = {
     'themes': themes
    }
    return render(request, 'dashbord/theme.html', context)

def encadreur(request):
    encadreurs = Encadreur.objects.all()
    return render(request, 'dashbord/encadreur.html', {
        'encadreurs': encadreurs,
    })

def detail_departement(request, id_dep):
    departement = Departement.objects.get(pk=id_dep)

    return render(request, 'dashbord/detail_departement.html',
    {
        'departement': departement,
    })

def detail_stagiaire(request, id_sta):
    stagiaire = Stagiaire.objects.get(pk=id_sta)

    return render(request, 'dashbord/detail_stagiaire.html',
    {
        'stagiaire': stagiaire,
    })

def detail_encadreur(request, id_enca):
    encadreur = Encadreur.objects.get(pk=id_enca)

    return render(request, 'dashbord/detail_encadreur.html',
    {
        'encadreur': encadreur,
    })

def detail_theme(request, id_theme):
    theme = Theme.objects.get(pk=id_theme)

    return render(request, 'dashbord/detail_theme.html',
    {
        'theme': theme,
    })
    
def detail_suivi(request, id_suivi):
    suivi = Suivi.objects.get(pk=id_suivi)

    return render(request, 'dashbord/detail_suivi.html',
    {
        'suivi': suivi,
    })


def update_theme(request, theme_id):
	theme = Theme.objects.get(pk=theme_id)
	form = ThemeForm(request.POST or None, instance=theme)
	if form.is_valid():
		form.save()
		return redirect('theme')
	return render(request, 'dashbord/update_theme.html', {
		'theme': theme,
		'form': form,
	})


def delete_theme(request, theme_id):
	theme = Theme.objects.get(pk=theme_id)
	theme.delete()
	return redirect('theme')


def update_stagiaire(request, stagiaire_id):
	stagiaire = Stagiaire.objects.get(pk=stagiaire_id)
	form = StagiaireForm(request.POST or None, instance=stagiaire)
	if form.is_valid():
		form.save()
		return redirect('stagiaire')
	return render(request, 'dashbord/update_stagiaire.html', {
		'stagiaire': stagiaire,
		'form': form,
	})


def delete_stagiaire(request, stagiaire_id):
	stagiaire = Stagiaire.objects.get(pk=stagiaire_id)
	stagiaire.delete()
	return redirect('stagiaire')

def update_departement(request, departement_id):
    departement = Departement.objects.get(pk=departement_id)
    form = DepartementForm(request.POST or None, instance=departement)
    if form.is_valid():
        form.save()
        return redirect('departement')
    return render(request, 'dashbord/update_departement.html', {
		'departement': departement,
		'form': form,
	})


def delete_departement(request, departement_id):
	departement = Departement.objects.get(pk=departement_id)
	departement.delete()
	return redirect('departement')

def update_suivi(request, suivi_id):
    suivi = Suivi.objects.get(pk=suivi_id)
    form = SuiviForm(request.POST or None, instance=suivi)
    if form.is_valid():
        form.save()
        return redirect('suivi')
    return render(request, 'dashbord/update_suivi.html', {
		'suivi': suivi,
		'form': form,
	})


def delete_suivi(request, suivi_id):
	suivi = Suivi.objects.get(pk=suivi_id)
	suivi.delete()
	return redirect('suivi')

def update_encadreur(request, encadreur_id):
    encadreur = Encadreur.objects.get(pk=encadreur_id)
    form = EncadreurForm(request.POST or None, instance=encadreur)
    if form.is_valid():
        form.save()
        return redirect('encadreur')
    return render(request, 'dashbord/update_encadreur.html', {
		'encadreur': encadreur,
		'form': form,
	})


def delete_encadreur(request, encadreur_id):
	encadreur = Encadreur.objects.get(pk=encadreur_id)
	encadreur.delete()
	return redirect('encadreur')

def search_suivi(request):
    if request.method == "POST":
        searched = request.POST['searched']
        suivi = Suivi.objects.filter(date_debut__contains=searched)
        return render(request, 'dashbord/search_suivi.html', {
            'searched': searched,
            'suivis': suivi,
        })
    else:
        return render(request, 'dashbord/search_suivi.html', {})

