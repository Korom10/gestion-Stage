from django.db import models

class Theme(models.Model):
    titre = models.TextField('titre')
    description = models.TextField('description')
    def __str__(self):
        return self.titre

class Stagiaire(models.Model):
    nom = models.CharField('nom', max_length=120)
    prenom = models.CharField('prenom', max_length=120)
    adresse = models.CharField('adresse', max_length=250)
    niveau = models.CharField('niveau', max_length=150)
    domaine = models.CharField('domaine', max_length=120)
    theme = models.ForeignKey(Theme, null=True, on_delete=models.SET_NULL)
    def __str__(self):
        return self.nom
    
class Departement(models.Model):
    nom = models.CharField('nom', max_length=120)
    description = models.CharField('description', null=True, max_length=120)

    def __str__(self):
        return self.nom
    
class Encadreur(models.Model):
    nom = models.CharField('nom', max_length=120)
    prenom = models.CharField('prenom', max_length=120)
    adresse = models.CharField('adresse', max_length=120)
    departement = models.ForeignKey(Departement, null=True, on_delete=models.SET_NULL)

    def __str__(self):
        return self.nom

    
class Suivi(models.Model):
    date_debut = models.DateField('date_debut')
    date_fin = models.DateField('date_fin')
    stage_effective = models.BooleanField('stage_effective')
    stagiaire = models.ForeignKey(Stagiaire, null=True, on_delete=models.SET_NULL)
    encadreur = models.ForeignKey(Encadreur, null=True, on_delete=models.SET_NULL)
    
    
    
    
    