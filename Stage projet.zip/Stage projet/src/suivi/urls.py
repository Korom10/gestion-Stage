from django.urls import path
from . import views



urlpatterns = [
        # //// read
        path('detail_departement/<id_dep>', views.detail_departement, name='detail-departement'),
        path('detail_stagiaire/<id_sta>', views.detail_stagiaire, name='detail-stagiaire'), 
        path('detail_encadreur/<id_enca>', views.detail_encadreur, name='detail-encadreur'), 
        path('detail_theme/<id_theme>', views.detail_theme, name='detail-theme'), 
        path('detail_suivi/<id_suivi>', views.detail_suivi, name='detail-suivi'), 
        # //// update
        path('update_theme/<theme_id>', views.update_theme, name='update-theme'), 
        path('update_stagiaire/<stagiaire_id>', views.update_stagiaire, name='update-stagiaire'), 
        path('update_departement/<departement_id>', views.update_departement, name='update-departement'),
        path('update_suivi/<suivi_id>', views.update_suivi, name='update-suivi'),
        path('update_encadreur/<encadreur_id>', views.update_encadreur, name='update-encadreur'),

        # //// delete
        path('delete_theme/<theme_id>', views.delete_theme, name='delete-theme'), 
        path('delete_stagiaire/<stagiaire_id>', views.delete_stagiaire, name='delete-stagiaire'),
        path('delete_departement/<departement_id>', views.delete_departement, name='delete-departement'),
        path('delete_suivi/<suivi_id>', views.delete_suivi, name='delete-suivi'),
        path('delete_encadreur/<encadreur_id>', views.delete_encadreur, name='delete-encadreur'),
        # ////search
        path('search_suivi', views.search_suivi, name='search-suivi'),
        




        



        path('', views.index, name='index'),
        path('add_stagiaire', views.add_stagiaire, name='add_stagiaire'),
        path('add_departement', views.add_departement, name='add_departement'),
        path('add_encadreur', views.add_encadreur, name='add_encadreur'),
        path('add_theme', views.add_theme, name='add_theme'),
        path('add_suivi', views.add_suivi, name='add_suivi'),
        path('suivi', views.suivi, name='suivi'),
        path('stagiaire', views.stagiaire, name='stagiaire'),
        path('encadreur', views.encadreur, name='encadreur'),
        path('departement', views.departement, name='departement'),
        path('theme', views.theme, name='theme'),

        
        #path('show_suivi/<suivi_id>', views.show_suivi, name='show_suivi'),



        
        
        
        
        
        
        
]