from django.contrib import admin
from .models import Stagiaire, Departement, Encadreur, Theme, Suivi

admin.site.register(Stagiaire)
admin.site.register(Departement)
admin.site.register(Encadreur)
admin.site.register(Theme)
admin.site.register(Suivi)
# class StagiaireAdmin(admin.ModelAdmin):
#     list_display = ('nom','prenom','adresse', 'niveau', 'domaine')
#     form = Stagiaire
#     ordering = ('-id', )
    
# admin.site.register(Stagiaire, StagiaireAdmin)

# class DepartementAdmin(admin.ModelAdmin):
#     list_display = ('nom')
#     form = Departement
#     ordering = ('-id', )
    
# admin.site.register(Departement, DepartementAdmin)

# class EncadreurAdmin(admin.ModelAdmin):
#     list_display = ('nom', 'prenom', 'adresse' )
#     form = Encadreur
#     ordering = ('-id', )
    
# admin.site.register(Encadreur, EncadreurAdmin)

# class ThemeAdmin(admin.ModelAdmin):
#     list_display = ('titre', 'description' )
#     form = Theme
#     ordering = ('-id', )
    
# admin.site.register(Theme, ThemeAdmin)

# class SuiviAdmin(admin.ModelAdmin):
#     list_display = ('date_debut', 'date_fin', 'stage_effective' )
#     form = Suivi
#     ordering = ('-id', )
    
# admin.site.register(Suivi, SuiviAdmin)


