from django import forms
from django.forms import ModelForm
from .models import Stagiaire, Departement, Encadreur, Theme, Suivi

class StagiaireForm(ModelForm):
    class Meta:
        model = Stagiaire
        fields = ('nom', 'prenom', 'adresse', 'niveau', 'domaine', 'theme')
        
class DepartementForm(ModelForm):
    class Meta:
        model = Departement
        fields = ('nom','description')
        
class EncadreurForm(ModelForm):
    class Meta:
        model = Encadreur
        fields = ('nom', 'prenom', 'adresse','departement')
        
class ThemeForm(ModelForm):
    class Meta:
        model = Theme
        fields = ('titre', 'description')
        
class SuiviForm(ModelForm):
    class Meta:
        model = Suivi
        fields = ('date_debut', 'date_fin', 'stage_effective', 'stagiaire', 'encadreur')
